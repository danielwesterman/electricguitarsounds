// Welch, Wright, & Morrow, 
// Real-time Digital Signal Processing, 2017

///////////////////////////////////////////////////////////////////////
// Filename: ISRs.c
//
// Synopsis: Interrupt service routine for codec data transmit/receive
//
///////////////////////////////////////////////////////////////////////

#include "DSP_Config.h" 
#include "Echo.h" 

// Data is received as 2 16-bit words (left/right) packed into one
// 32-bit word.  The union allows the data to be accessed as a single 
// entity when transferring to and from the serial port, but still be 
// able to manipulate the left and right channels independently.

#define LEFT  0
#define RIGHT 1

volatile union {
	Uint32 UINT;
	Int16 Channel[2];
} CodecDataIn, CodecDataOut;

/* add any global variables here */
float xLeft, xRight, yLeft, yRight;
Uint32 oldest1 = 0; // index for buffer value
Uint32 oldest2 = 0; // index for buffer value
Uint32 oldest3 = 0; // index for buffer value
#pragma DATA_SECTION (buffer1, "CE0"); // put "buffer" in SDRAM
#pragma DATA_SECTION (buffer2, "CE0"); // put "buffer" in SDRAM
#pragma DATA_SECTION (buffer3, "CE0"); // put "buffer" in SDRAM
volatile float buffer1[2][BUFFER1_LENGTH]; // space for left + right
volatile float buffer2[2][BUFFER2_LENGTH]; // space for left + right
volatile float buffer3[2][BUFFER3_LENGTH]; // space for left + right
volatile float gain1 = 2; /* set gain value for echoed sample */
volatile float gain2 = 1.5; /* set gain value for echoed sample */
volatile float gain3 = 1.3; /* set gain value for echoed sample */

void ZeroBuffer()
///////////////////////////////////////////////////////////////////////
// Purpose:   Initial fill of all buffer locations with 0.0
//
// Input:     None
//
// Returns:   Nothing
//
// Calls:     Nothing
//
// Notes:     None
///////////////////////////////////////////////////////////////////////
{
    int i;

    for(i=0; i < BUFFER1_LENGTH; i++)  {
        buffer1[LEFT][i] = 0.0;
        buffer1[RIGHT][i] = 0.0;
        }
    for(i=0; i < BUFFER2_LENGTH; i++)  {
            buffer2[LEFT][i] = 0.0;
            buffer2[RIGHT][i] = 0.0;
            }
    for(i=0; i < BUFFER3_LENGTH; i++)  {
            buffer3[LEFT][i] = 0.0;
            buffer3[RIGHT][i] = 0.0;
            }
}

interrupt void Codec_ISR()
///////////////////////////////////////////////////////////////////////
// Purpose:   Codec interface interrupt service routine  
//
// Input:     None
//
// Returns:   Nothing
//
// Calls:     CheckForOverrun, ReadCodecData, WriteCodecData
//
// Notes:     None
///////////////////////////////////////////////////////////////////////
{                    
	/* add any local variables here */

    if(CheckForOverrun())                   // overrun error occurred (i.e. halted DSP)
        return;                             // so serial port is reset to recover

    CodecDataIn.UINT = ReadCodecData();     // get input data samples

    /* add your code starting here */

    /****************************
    ECHO ROUTINE BEGINS HERE
    ****************************/
    xLeft = CodecDataIn.Channel[LEFT];   // current LEFT input value to float
    xRight = CodecDataIn.Channel[RIGHT];   // current RIGHT input value to float

    buffer1[LEFT][oldest1] = xLeft;
    buffer1[RIGHT][oldest1] = xRight;
    buffer2[LEFT][oldest2] = xLeft;
    buffer2[RIGHT][oldest2] = xRight;
    buffer3[LEFT][oldest3] = xLeft;
    buffer3[RIGHT][oldest3] = xRight;

    if (++oldest1 >= BUFFER1_LENGTH) // implement circular buffer
        oldest1 = 0;

    if (++oldest2 >= BUFFER2_LENGTH) // implement circular buffer
           oldest2 = 0;

    if (++oldest3 >= BUFFER3_LENGTH) // implement circular buffer
           oldest3 = 0;
    // use either FIR or IIR lines below

    // for FIR comb filter effect, uncomment next two lines

    int delayedIndex1 = (oldest1  + (int)B1[sampleNum1]) % BUFFER1_LENGTH;
    int delayedIndex2 = (oldest2  + (int)B2[sampleNum2]) % BUFFER2_LENGTH;
    int delayedIndex3 = (oldest3  + (int)B3[sampleNum3]) % BUFFER3_LENGTH;

    if (count1++ >= 3){
    if (++sampleNum1 >= SAMPLE_RATE)
            sampleNum1 = 0;
    count1 = 0;
    }
    if (count2++ >= 5){
    if (++sampleNum2 >= SAMPLE_RATE)
            sampleNum2 = 0;
    count2 = 0;
    }
    if (count3++ >= 7){
    if (++sampleNum3 >= SAMPLE_RATE)
            sampleNum3 = 0;
    count3 = 0;
    }

    yLeft =  xLeft  + (gain1 * buffer1[LEFT][delayedIndex1] + xLeft) + (gain2 * buffer2[LEFT][delayedIndex2] + xLeft) + (gain3 * buffer3[LEFT][delayedIndex3] + xLeft);
    yRight =  xRight + (gain1 * buffer1[RIGHT][delayedIndex1] +xRight) + (gain2 * buffer2[RIGHT][delayedIndex2] + xRight) + (gain3 * buffer3[RIGHT][delayedIndex3] + xRight);
    
	// for IIR comb filter effect, uncomment four lines below
	//buffer[LEFT][newest] = xLeft + (gain * buffer[LEFT][oldest]);
	//buffer[RIGHT][newest] = xRight + (gain * buffer[RIGHT][oldest]);
	//yLeft = buffer[LEFT][oldest];  // or use newest 
	//yRight = buffer[RIGHT][oldest];  // or use newest

	CodecDataOut.Channel[LEFT] = xLeft;   // setup the LEFT value
	CodecDataOut.Channel[RIGHT] = yRight/5; // setup the RIGHT value
	/*****************************/
	/* end your code here */

	WriteCodecData(CodecDataOut.UINT);		// send output data to  port
}

