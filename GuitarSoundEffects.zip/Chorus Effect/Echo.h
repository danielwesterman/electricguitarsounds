// Welch, Wright, & Morrow, 
// Real-time Digital Signal Processing, 2017

///////////////////////////////////////////////////////////////////////
// Filename: Echo.h
//
// Synopsis: Declarations specific to this project
//
///////////////////////////////////////////////////////////////////////

#ifndef ECHO_H_INCLUDED
#define ECHO_H_INCLUDED


// function prototypes
void ZeroBuffer(void);
#define BUFFER1_LENGTH  1104 // buffer length in samples
#define BUFFER2_LENGTH  1392 // buffer length in samples
#define BUFFER3_LENGTH  912 // buffer length in samples
#define SAMPLE_RATE 16000
volatile float B1[SAMPLE_RATE];
volatile float B2[SAMPLE_RATE];
volatile float B3[SAMPLE_RATE];
volatile int sampleNum1;
volatile int sampleNum2;
volatile int sampleNum3;
volatile int count1;
volatile int count2;
volatile int count3;

#endif
