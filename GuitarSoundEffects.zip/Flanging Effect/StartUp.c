#include "DSP_Config.h"
#include "Echo.h"
#define PI 3.141592654
#include <stdio.h>
#include <math.h>


// Global variable
 // Adjust size as necessary

void StartUp()
{
    sampleNum = 0;
    ZeroBuffer();   // Set all buffer values to zero

    // Maximum delay in samples (adjust as needed)
    int i;
    float f0 = 1;  // Flanging frequency of 1 Hz
    for (i = 0; i < SAMPLE_RATE; i++) {
        B[i] = ((BUFFER_LENGTH-1) / 2) * (1 - cos(2 * PI * f0 * i / SAMPLE_RATE));
    }
}
