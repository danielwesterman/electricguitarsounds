#include "DSP_Config.h"
#include "Echo.h"
#define PI 3.141592654
#include <stdio.h>
#include <math.h>


// Global variable
 // Adjust size as necessary

void StartUp()
{
    sampleNum1 = 0;
    sampleNum2 = 0;
    sampleNum3 = 0;
    count1 = 0;
    count2 = 0;
    count3 = 0;
    ZeroBuffer();   // Set all buffer values to zero

    // Maximum delay in samples (adjust as needed)
    int i;
    float f0 = 1; // Flanging frequency of 1 Hz
    for (i = 0; i < SAMPLE_RATE; i++) {
        B1[i] = ((BUFFER1_LENGTH-1) / 2) * (1 - cos(2 * PI * f0 * i / (SAMPLE_RATE)));
    }
    for (i = 0; i < SAMPLE_RATE; i++) {
            B2[i] = ((BUFFER2_LENGTH-1) / 2) * (1 - cos(2 * PI * f0 * i / SAMPLE_RATE));
        }
    for (i = 0; i < SAMPLE_RATE; i++) {
            B3[i] = ((BUFFER3_LENGTH-1) / 2) * (1 - cos(2 * PI * f0 * i / SAMPLE_RATE));
        }
}
